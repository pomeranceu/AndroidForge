package cz.vashek.csharpstudio;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceRequest;
import android.os.Build;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final int REQUEST_OPEN = 4101;
    private static final int REQUEST_SAVE = 4102;
    private WebView webView;
    private String pendingSaveContent = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (Build.VERSION.SDK_INT >= 30) getWindow().setDecorFitsSystemWindows(true);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(11, 16, 32));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(11, 16, 32));

        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setDatabaseEnabled(true);
        settings.setTextZoom(100);
        webView.setBackgroundColor(android.graphics.Color.rgb(11, 16, 32));
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if ("https".equalsIgnoreCase(uri.getScheme()) || "http".equalsIgnoreCase(uri.getScheme())) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); } catch (Exception ignored) { }
                    return true;
                }
                return false;
            }
        });
        webView.addJavascriptInterface(new AppBridge(), "Android");
        webView.loadUrl("file:///android_asset/index.html");
    }

    private class AppBridge {
        @JavascriptInterface
        public void importFile() {
            runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
                        "text/*", "application/octet-stream", "application/x-csharp"
                });
                startActivityForResult(intent, REQUEST_OPEN);
            });
        }

        @JavascriptInterface
        public void saveAs(String fileName, String content) {
            runOnUiThread(() -> {
                pendingSaveContent = content == null ? "" : content;
                String safeName = (fileName == null || fileName.trim().isEmpty()) ? "Program.cs" : fileName.trim();
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("text/plain");
                intent.putExtra(Intent.EXTRA_TITLE, safeName);
                startActivityForResult(intent, REQUEST_SAVE);
            });
        }

        @JavascriptInterface
        public void pasteFromClipboard() {
            runOnUiThread(() -> {
                ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                String text = "";
                if (clipboard != null && clipboard.hasPrimaryClip()) {
                    ClipData clip = clipboard.getPrimaryClip();
                    if (clip != null && clip.getItemCount() > 0) {
                        CharSequence value = clip.getItemAt(0).coerceToText(MainActivity.this);
                        if (value != null) text = value.toString();
                    }
                }
                webView.evaluateJavascript("window.receiveClipboard(" + JSONObject.quote(text) + ")", null);
            });
        }

        @JavascriptInterface
        public void runCsharp(String code, String input, String apiKey) {
            new Thread(() -> executeCsharp(code, input, apiKey)).start();
        }
    }

    private void executeCsharp(String code, String input, String apiKey) {
        JSONObject result;
        HttpURLConnection connection = null;
        try {
            if (apiKey == null || apiKey.trim().isEmpty()) {
                throw new IllegalArgumentException("Chybí API klíč. Otevři Nastavení a vlož svůj klíč z OnlineCompiler.io.");
            }

            JSONObject request = new JSONObject();
            request.put("compiler", "dotnet-csharp-10");
            request.put("code", code == null ? "" : code);
            request.put("input", input == null ? "" : input);

            URL url = new URL("https://api.onlinecompiler.io/api/run-code-sync/");
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setConnectTimeout(15000);
            connection.setReadTimeout(45000);
            connection.setDoOutput(true);
            connection.setRequestProperty("Authorization", apiKey.trim());
            connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            connection.setRequestProperty("Accept", "application/json");

            byte[] body = request.toString().getBytes(StandardCharsets.UTF_8);
            connection.setFixedLengthStreamingMode(body.length);
            try (OutputStream output = connection.getOutputStream()) {
                output.write(body);
            }

            int status = connection.getResponseCode();
            InputStream stream = (status >= 200 && status < 300)
                    ? connection.getInputStream() : connection.getErrorStream();
            String responseText = readAll(stream);
            result = new JSONObject(responseText);
            if (status < 200 || status >= 300) {
                String message = result.optString("message", "HTTP " + status);
                result.put("client_error", message);
            }
        } catch (Exception ex) {
            result = new JSONObject();
            try {
                result.put("status", "error");
                result.put("error", ex.getMessage() == null ? ex.toString() : ex.getMessage());
            } catch (JSONException ignored) { }
        } finally {
            if (connection != null) connection.disconnect();
        }

        final String json = result.toString();
        runOnUiThread(() -> webView.evaluateJavascript(
                "window.onRunResult(" + JSONObject.quote(json) + ")", null));
    }

    private String readAll(InputStream input) throws Exception {
        if (input == null) return "{}";
        try (InputStream in = input; ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192];
            int count;
            while ((count = in.read(buffer)) != -1) out.write(buffer, 0, count);
            return out.toString("UTF-8");
        }
    }

    @Override
    @SuppressWarnings("deprecation")
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        if (requestCode == REQUEST_OPEN) {
            try {
                String name = queryName(uri);
                String contents;
                try (InputStream in = getContentResolver().openInputStream(uri)) {
                    if (in == null) throw new IllegalStateException("Soubor se nepodařilo otevřít.");
                    contents = readAll(in);
                }
                webView.evaluateJavascript(
                        "window.receiveImportedFile(" + JSONObject.quote(name) + "," + JSONObject.quote(contents) + ")", null);
            } catch (Exception ex) {
                Toast.makeText(this, "Import se nezdařil: " + ex.getMessage(), Toast.LENGTH_LONG).show();
            }
        } else if (requestCode == REQUEST_SAVE) {
            try (OutputStream out = getContentResolver().openOutputStream(uri, "w")) {
                if (out == null) throw new IllegalStateException("Nelze zapisovat do vybraného umístění.");
                out.write(pendingSaveContent.getBytes(StandardCharsets.UTF_8));
                Toast.makeText(this, "Soubor byl uložen.", Toast.LENGTH_SHORT).show();
                webView.evaluateJavascript("window.onSaveFinished(true)", null);
            } catch (Exception ex) {
                Toast.makeText(this, "Uložení se nezdařilo: " + ex.getMessage(), Toast.LENGTH_LONG).show();
                webView.evaluateJavascript("window.onSaveFinished(false)", null);
            } finally {
                pendingSaveContent = "";
            }
        }
    }

    private String queryName(Uri uri) {
        try (Cursor cursor = getContentResolver().query(uri, null, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (index >= 0) return cursor.getString(index);
            }
        } catch (Exception ignored) { }
        String path = uri.getLastPathSegment();
        return path == null ? "Imported.cs" : path;
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
