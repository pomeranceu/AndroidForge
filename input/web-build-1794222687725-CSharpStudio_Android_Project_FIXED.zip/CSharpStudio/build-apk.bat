@echo off
setlocal
where gradle >nul 2>nul
if errorlevel 1 (
  echo Gradle nebyl nalezen v PATH.
  echo Otevrete slozku projektu v Android Studiu a pouzijte Build ^> Build APK(s).
  pause
  exit /b 1
)
gradle :app:assembleDebug
if errorlevel 1 exit /b 1
echo.
echo APK: app\build\outputs\apk\debug\app-debug.apk
endlocal
