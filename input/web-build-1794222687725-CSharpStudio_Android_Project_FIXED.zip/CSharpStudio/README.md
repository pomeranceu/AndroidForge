# C# Studio – Android

Jednoduchý mobilní C# editor pro Android. Aplikace má lokální editor se zvýrazněním syntaxe, import a export souborů a online spuštění C# přes .NET 10.

## Co funguje

- Editor C# je součástí APK a funguje bez internetu.
- Zvýraznění klíčových slov, typů, řetězců, čísel, komentářů a volání metod.
- Import textových a `.cs` souborů přes systémový výběr souborů Androidu.
- Vložení obsahu schránky, vytvoření nového souboru a uložení přes „Uložit“.
- Lokální automatické uchování rozepsaného kódu v úložišti aplikace.
- Vstup pro `Console.ReadLine()` a panel výstupu/chyb.
- Spuštění přes OnlineCompiler.io, kompilátor `dotnet-csharp-10`.

## Omezení spuštění

Plnohodnotný .NET SDK a runtime nejsou zabalené v této první verzi APK. Proto se zdrojový kód spouští online. Samotné psaní, úpravy, import a ukládání fungují offline.

Pro online spuštění je potřeba bezplatný API klíč:

1. Otevři https://api.onlinecompiler.io/ a vytvoř si účet/API klíč.
2. V aplikaci otevři ⚙ Nastavení.
3. Vlož API klíč a ulož ho.
4. Napiš C# kód a klepni na **Spustit**.

Při každém spuštění se kód a vstup odešlou na servery OnlineCompiler.io. Neposílej tam hesla, tokeny ani jiná tajná data.

## Sestavení APK ve Windows

Požadavky:

- Android Studio s Android SDK Platform 36
- JDK 17 nebo novější (doporučeno JDK 21)
- Android Gradle Plugin 8.13.2 a Gradle 8.13 (Android Studio je umí stáhnout při synchronizaci projektu)

Postup:

1. Rozbal ZIP.
2. V Android Studiu zvol **Open** a vyber složku `CSharpStudio` (tu, ve které je `settings.gradle`).
3. Počkej na Gradle Sync a případně potvrď stažení Android SDK 36.
4. Zvol **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Debug APK najdeš v `app/build/outputs/apk/debug/app-debug.apk`.

Případně z terminálu v kořenové složce projektu spusť `gradle :app:assembleDebug`, pokud máš Gradle 8.13 v PATH a nastavené Android SDK.

## Projekt

- `app/src/main/java/.../MainActivity.java` – Android část, import/export a síťové volání kompilátoru.
- `app/src/main/assets/index.html` – editor a uživatelské rozhraní.

Projekt nemá žádné externí Android knihovny; používá standardní Android SDK a systémový WebView.
